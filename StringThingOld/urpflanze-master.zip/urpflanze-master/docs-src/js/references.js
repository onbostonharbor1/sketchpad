export default {
	Core: 'https://docs.urpflanze.org/core/',
	DrawerCanvas: 'https://docs.urpflanze.org/drawer-canvas/',
	Animation: 'https://docs.urpflanze.org/animation',
	SVGImporter: 'https://github.com/urpflanze-org/svg-importer',
	SVGExporter: 'https://github.com/urpflanze-org/svg-exporter',
	GCODEExporter: 'https://github.com/urpflanze-org/gcode-exporter',
}
